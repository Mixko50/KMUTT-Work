package com.example.layout_interactive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
