package com.example.midterm13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
