package com.example.multi_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
