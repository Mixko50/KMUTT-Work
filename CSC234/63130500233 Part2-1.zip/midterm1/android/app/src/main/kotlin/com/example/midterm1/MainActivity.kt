package com.example.midterm1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
